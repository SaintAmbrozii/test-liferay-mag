package com.example.shopinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopInfoApplicationTests {

    @Test
    void contextLoads() {
    }

}
