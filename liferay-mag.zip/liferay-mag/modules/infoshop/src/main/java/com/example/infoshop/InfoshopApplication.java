package com.example.infoshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InfoshopApplication {

    public static void main(String[] args) {
        SpringApplication.run(InfoshopApplication.class, args);
    }

}
