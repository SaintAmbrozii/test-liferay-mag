package com.example.infoshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfoshopApplicationTests {

    @Test
    void contextLoads() {
    }

}
